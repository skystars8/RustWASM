//! Browser-local hashing compiled to WebAssembly.
//!
//! The exported interface deliberately uses WebAssembly's basic numeric ABI so
//! the finished module needs no JavaScript package or runtime glue.

use sha2::{Digest, Sha256, Sha384, Sha512};
use sha3::{Sha3_224, Sha3_256, Sha3_384, Sha3_512};
use std::alloc::{Layout, alloc, dealloc};
use std::ptr;
use std::slice;

pub const SHA3_512: u32 = 0;
pub const SHA3_384: u32 = 1;
pub const SHA3_256: u32 = 2;
pub const SHA3_224: u32 = 3;
pub const SHA_512: u32 = 4;
pub const SHA_384: u32 = 5;
pub const SHA_256: u32 = 6;
pub const BLAKE3: u32 = 7;

/// Hashes exact bytes without trimming or Unicode normalization.
pub fn hash_bytes(algorithm: u32, input: &[u8]) -> Option<Vec<u8>> {
    match algorithm {
        SHA3_512 => Some(Sha3_512::digest(input).to_vec()),
        SHA3_384 => Some(Sha3_384::digest(input).to_vec()),
        SHA3_256 => Some(Sha3_256::digest(input).to_vec()),
        SHA3_224 => Some(Sha3_224::digest(input).to_vec()),
        SHA_512 => Some(Sha512::digest(input).to_vec()),
        SHA_384 => Some(Sha384::digest(input).to_vec()),
        SHA_256 => Some(Sha256::digest(input).to_vec()),
        BLAKE3 => Some(blake3::hash(input).as_bytes().to_vec()),
        _ => None,
    }
}

/// Allocates a byte buffer in WebAssembly linear memory for JavaScript.
#[unsafe(no_mangle)]
pub extern "C" fn allocate(length: usize) -> *mut u8 {
    if length == 0 {
        return ptr::null_mut();
    }

    let Ok(layout) = Layout::array::<u8>(length) else {
        return ptr::null_mut();
    };

    // SAFETY: The matching layout is passed back to `deallocate` by the caller.
    unsafe { alloc(layout) }
}

/// Releases a buffer previously returned by [`allocate`].
///
/// # Safety
///
/// `pointer` must be either null or a pointer returned by [`allocate`], and
/// `length` must exactly match the length used for that allocation. The region
/// must not have been released already.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn deallocate(pointer: *mut u8, length: usize) {
    if pointer.is_null() || length == 0 {
        return;
    }

    if let Ok(layout) = Layout::array::<u8>(length) {
        // SAFETY: The JavaScript wrapper only passes pointers created by
        // `allocate` together with their original lengths.
        unsafe { dealloc(pointer, layout) };
    }
}

/// Hashes bytes from linear memory into a caller-provided output buffer.
///
/// Returns the digest length, or a negative error code:
/// - `-1`: unknown algorithm
/// - `-2`: invalid pointer
/// - `-3`: output buffer is too small
///
/// # Safety
///
/// When `input_length` is nonzero, `input_pointer` must reference a readable
/// allocation of at least that many bytes. `output_pointer` must reference a
/// writable allocation of at least `output_capacity` bytes, and the two regions
/// must not overlap.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn hash(
    algorithm: u32,
    input_pointer: *const u8,
    input_length: usize,
    output_pointer: *mut u8,
    output_capacity: usize,
) -> i32 {
    if (input_length > 0 && input_pointer.is_null()) || output_pointer.is_null() {
        return -2;
    }

    let input = if input_length == 0 {
        &[]
    } else {
        // SAFETY: The caller allocated this region and supplies its exact size.
        unsafe { slice::from_raw_parts(input_pointer, input_length) }
    };

    let Some(digest) = hash_bytes(algorithm, input) else {
        return -1;
    };

    if output_capacity < digest.len() {
        return -3;
    }

    // SAFETY: Capacity was checked immediately above; source and destination
    // are separate allocations managed by the JavaScript wrapper.
    unsafe { ptr::copy_nonoverlapping(digest.as_ptr(), output_pointer, digest.len()) };

    digest.len() as i32
}

#[cfg(test)]
mod tests {
    use super::*;

    fn hex(bytes: &[u8]) -> String {
        bytes.iter().map(|byte| format!("{byte:02x}")).collect()
    }

    #[test]
    fn sha3_512_matches_nist_empty_vector() {
        assert_eq!(
            hex(&hash_bytes(SHA3_512, b"").unwrap()),
            "a69f73cca23a9ac5c8b567dc185a756e97c982164fe25859e0d1dcc1475c80a6\
             15b2123af1f5f94c11e3e9402c3ac558f500199d95b6d3e301758586281dcd26"
                .replace(' ', "")
        );
    }

    #[test]
    fn algorithms_match_known_abc_vectors() {
        let cases = [
            (
                SHA3_512,
                "b751850b1a57168a5693cd924b6b096e08f621827444f70d884f5d0240d2712\
                 e10e116e9192af3c91a7ec57647e3934057340b4cf408d5a56592f8274eec53f0",
            ),
            (
                SHA3_384,
                "ec01498288516fc926459f58e2c6ad8df9b473cb0fc08c2596da7cf0e49be4b2\
                 98d88cea927ac7f539f1edf228376d25",
            ),
            (
                SHA3_256,
                "3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532",
            ),
            (
                SHA3_224,
                "e642824c3f8cf24ad09234ee7d3c766fc9a3a5168d0c94ad73b46fdf",
            ),
            (
                SHA_512,
                "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a\
                 2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f",
            ),
            (
                SHA_384,
                "cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed\
                 8086072ba1e7cc2358baeca134c825a7",
            ),
            (
                SHA_256,
                "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            ),
            (
                BLAKE3,
                "6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85",
            ),
        ];

        for (algorithm, expected) in cases {
            assert_eq!(
                hex(&hash_bytes(algorithm, b"abc").unwrap()),
                expected.replace(' ', "")
            );
        }
    }

    #[test]
    fn hashes_utf8_bytes_without_normalization() {
        let composed = hash_bytes(SHA3_512, "é".as_bytes()).unwrap();
        let decomposed = hash_bytes(SHA3_512, "e\u{301}".as_bytes()).unwrap();

        assert_ne!(composed, decomposed);
        assert_eq!(
            hex(&composed),
            "240f197bab9d86d25a7b12ab903acd0df93cc8eb25f61eb4a3a24a7d710a3ee2\
             8c19a1a7b70dcc25ed8003ee5f96adf864b4d101405888d28980c44597feefc1"
                .replace(' ', "")
        );
    }

    #[test]
    fn rejects_unknown_algorithms() {
        assert!(hash_bytes(99, b"abc").is_none());
    }
}
