# LocalHash

LocalHash is a private, browser-local text hashing utility. Its cryptographic
engine is written in Rust and compiled to WebAssembly; the input never leaves
the page.

## Fastest way to use it

After a build, open `dist-portable/LocalHash.html` in any current browser on
Linux, Windows, or macOS. It is a self-contained file: the CSS, JavaScript, and
compiled WebAssembly engine are embedded, so it does not need a web server or
an internet connection.

Type or paste text, choose an algorithm, then use **Copy hash**. The output is
lowercase hexadecimal. Empty text is valid, and spaces, capitalization,
newlines, and Unicode bytes are preserved exactly.

Supported algorithms:

- SHA3-512 (default), SHA3-384, SHA3-256, and SHA3-224
- SHA-512, SHA-384, and SHA-256
- BLAKE3

## Build from source

For complete setup, build, test, development, and cleanup instructions, see
[`BUILDING.md`](BUILDING.md).

Requirements:

- Rust 1.85 or newer, plus Cargo
- The `wasm32-unknown-unknown` Rust target
- Node.js 22.13 or newer with npm (or pnpm)

```sh
rustup target add wasm32-unknown-unknown
npm ci --ignore-scripts
npm run build
npm test
```

For the interactive development site, run `npm run dev`. The compiled WASM
module is emitted to `public/hash_engine.wasm`; the completely standalone app
is emitted to `dist-portable/LocalHash.html`.

## Architecture

- `engine/` — Rust digest implementation and a small WebAssembly memory ABI
- `app/` — responsive React interface for the hosted/development version
- `portable/` — source template for the single-file offline edition
- `scripts/` — repeatable WASM and portable-artifact builders
- `tests/` — Rust vectors plus tests against the compiled `.wasm` module

Hashes are useful for fingerprints and integrity checks. They are not
encryption, and fast general-purpose hashes are not suitable for storing
passwords; use a password-hashing construction such as Argon2id for that.
