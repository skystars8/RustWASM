import assert from "node:assert/strict";
import test from "node:test";

async function renderHome() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("production render presents the finished hashing interface", async () => {
  const response = await renderHome();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>LocalHash — Private browser hashing<\/title>/i);
  assert.match(html, /A fingerprint for/);
  assert.match(html, /SHA3-512/);
  assert.match(html, /Copy hash/);
  assert.match(html, /Private by design/);
  assert.doesNotMatch(html, /codex-preview|SkeletonPreview|site-creator-vinext-starter/);
});

