import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const wasmPath = new URL("../public/hash_engine.wasm", import.meta.url);

async function loadEngine() {
  const binary = await readFile(wasmPath);
  const result = await WebAssembly.instantiate(binary);
  return result.instance.exports;
}

function hashText(engine, algorithm, value, outputLength) {
  const input = new TextEncoder().encode(value);
  const inputCapacity = Math.max(1, input.length);
  const inputPointer = engine.allocate(inputCapacity);
  const outputPointer = engine.allocate(outputLength);

  try {
    new Uint8Array(engine.memory.buffer, inputPointer, input.length).set(input);
    const length = engine.hash(
      algorithm,
      inputPointer,
      input.length,
      outputPointer,
      outputLength,
    );
    assert.equal(length, outputLength);
    return Buffer.from(
      new Uint8Array(engine.memory.buffer, outputPointer, length),
    ).toString("hex");
  } finally {
    engine.deallocate(outputPointer, outputLength);
    engine.deallocate(inputPointer, inputCapacity);
  }
}

test("compiled WebAssembly returns known SHA3-512 values", async () => {
  const engine = await loadEngine();

  assert.equal(
    hashText(engine, 0, "", 64),
    "a69f73cca23a9ac5c8b567dc185a756e97c982164fe25859e0d1dcc1475c80a615b2123af1f5f94c11e3e9402c3ac558f500199d95b6d3e301758586281dcd26",
  );
  assert.equal(
    hashText(engine, 0, "abc", 64),
    "b751850b1a57168a5693cd924b6b096e08f621827444f70d884f5d0240d2712e10e116e9192af3c91a7ec57647e3934057340b4cf408d5a56592f8274eec53f0",
  );
});

test("compiled WebAssembly supports every offered family", async () => {
  const engine = await loadEngine();
  const cases = [
    [1, 48, "ec01498288516fc926459f58e2c6ad8df9b473cb0fc08c2596da7cf0e49be4b298d88cea927ac7f539f1edf228376d25"],
    [2, 32, "3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532"],
    [3, 28, "e642824c3f8cf24ad09234ee7d3c766fc9a3a5168d0c94ad73b46fdf"],
    [4, 64, "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f"],
    [5, 48, "cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed8086072ba1e7cc2358baeca134c825a7"],
    [6, 32, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"],
    [7, 32, "6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85"],
  ];

  for (const [algorithm, length, expected] of cases) {
    assert.equal(hashText(engine, algorithm, "abc", length), expected);
  }
});

test("compiled WebAssembly hashes UTF-8 bytes exactly", async () => {
  const engine = await loadEngine();
  assert.equal(
    hashText(engine, 0, "é", 64),
    "240f197bab9d86d25a7b12ab903acd0df93cc8eb25f61eb4a3a24a7d710a3ee28c19a1a7b70dcc25ed8003ee5f96adf864b4d101405888d28980c44597feefc1",
  );
  assert.notEqual(hashText(engine, 0, "é", 64), hashText(engine, 0, "e\u0301", 64));
});
