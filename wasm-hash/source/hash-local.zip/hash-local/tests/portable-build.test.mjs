import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("portable build is self-contained and copy-capable", async () => {
  const html = await readFile(
    new URL("../dist-portable/LocalHash.html", import.meta.url),
    "utf8",
  );

  assert.doesNotMatch(html, /__LOCALHASH_/);
  assert.doesNotMatch(html, /<script\s+[^>]*src=/i);
  assert.doesNotMatch(html, /<link\s+[^>]*stylesheet/i);
  assert.match(html, /WebAssembly\.instantiate\(binary\)/);
  assert.match(html, /navigator\.clipboard\?\.writeText/);
  assert.match(html, /document\.execCommand\("copy"\)/);
  assert.match(html, /SHA3-512/);
});

