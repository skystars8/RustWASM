import { copyFile, mkdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifest = path.join(root, "engine", "Cargo.toml");

const result = spawnSync(
  "cargo",
  [
    "build",
    "--manifest-path",
    manifest,
    "--target",
    "wasm32-unknown-unknown",
    "--release",
    "--locked",
  ],
  { cwd: root, stdio: "inherit" },
);

if (result.error) {
  throw result.error;
}

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}

const source = path.join(
  root,
  "engine",
  "target",
  "wasm32-unknown-unknown",
  "release",
  "hash_engine.wasm",
);
const destination = path.join(root, "public", "hash_engine.wasm");

await mkdir(path.dirname(destination), { recursive: true });
await copyFile(source, destination);

console.log(`WASM engine copied to ${path.relative(root, destination)}`);

