import { mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const [template, stylesheet, wasm] = await Promise.all([
  readFile(path.join(root, "portable", "template.html"), "utf8"),
  readFile(path.join(root, "app", "globals.css"), "utf8"),
  readFile(path.join(root, "public", "hash_engine.wasm")),
]);

const standaloneStyles = stylesheet.replace(/^@import\s+"tailwindcss";\s*/u, "");
const output = template
  .replace("__LOCALHASH_STYLES__", standaloneStyles)
  .replace("__LOCALHASH_WASM_BASE64__", wasm.toString("base64"));

if (output.includes("__LOCALHASH_")) {
  throw new Error("A portable-build placeholder was not replaced.");
}

const outputDirectory = path.join(root, "dist-portable");
const outputPath = path.join(outputDirectory, "LocalHash.html");
await mkdir(outputDirectory, { recursive: true });
await writeFile(outputPath, output);

console.log(`Standalone app written to ${path.relative(root, outputPath)}`);

