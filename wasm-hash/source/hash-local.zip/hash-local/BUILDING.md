# Building LocalHash

LocalHash has two parts: a Rust hashing engine compiled to WebAssembly and a
TypeScript/React browser interface. The normal build command produces both the
web application and a self-contained offline HTML file.

## Requirements

- Rust 1.85 or newer with Cargo and rustup
- Node.js 22.13 or newer with npm

Check the installed versions:

```sh
rustc --version
cargo --version
node --version
npm --version
```

## First-time setup

Run these commands from the `hash-local` directory:

```sh
rustup target add wasm32-unknown-unknown
npm ci --ignore-scripts
```

The WebAssembly target is required because Cargo normally builds native
programs for the current operating system.

## Production build

```sh
npm run build
```

This command:

1. Compiles `engine/src/lib.rs` into optimized WebAssembly.
2. Copies the module to `public/hash_engine.wasm`.
3. Builds the React web application into `dist/`.
4. Embeds the WASM, CSS, and JavaScript into
   `dist-portable/LocalHash.html`.

The portable HTML file can be opened directly in a current browser without a
server or internet connection.

## Tests

```sh
npm test
npm run lint
```

The tests verify the native Rust implementation, the compiled WebAssembly
module, standard hash vectors, the portable file, and the rendered application.

## Development server

```sh
npm run dev
```

Open the local address printed in the terminal. If the Rust engine changes,
restart the development command so the WASM module is rebuilt.

## Cleaning generated files

Remove Rust build artifacts with:

```sh
cargo clean --manifest-path engine/Cargo.toml
```

Do not upload `node_modules/`, `engine/target/`, `dist/`, `.next/`, `.vinext/`,
or `.wrangler/` to GitHub. They are generated locally and covered by the
project's `.gitignore`.

