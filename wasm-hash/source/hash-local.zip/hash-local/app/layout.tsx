import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LocalHash",
  description:
    "Private SHA-3, SHA-2, and BLAKE3 hashing, powered locally by Rust and WebAssembly.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
