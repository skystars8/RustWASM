import type { Metadata } from "next";
import { HashTool } from "./HashTool";

export const metadata: Metadata = {
  title: "LocalHash — Private browser hashing",
  description:
    "Generate SHA3-512, SHA-2, and BLAKE3 hashes locally with a Rust WebAssembly engine.",
};

export default function Home() {
  return <HashTool />;
}

