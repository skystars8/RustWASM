"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type HashEngine = {
  memory: WebAssembly.Memory;
  allocate: (length: number) => number;
  deallocate: (pointer: number, length: number) => void;
  hash: (
    algorithm: number,
    inputPointer: number,
    inputLength: number,
    outputPointer: number,
    outputCapacity: number,
  ) => number;
};

type Algorithm = {
  id: string;
  wasmId: number;
  name: string;
  family: string;
  bits: number;
  bytes: number;
  description: string;
};

const algorithms: Algorithm[] = [
  {
    id: "sha3-512",
    wasmId: 0,
    name: "SHA3-512",
    family: "SHA-3",
    bits: 512,
    bytes: 64,
    description:
      "A modern 512-bit digest from NIST’s SHA-3 family, ideal for high-confidence integrity checks.",
  },
  {
    id: "sha3-384",
    wasmId: 1,
    name: "SHA3-384",
    family: "SHA-3",
    bits: 384,
    bytes: 48,
    description:
      "A compact SHA-3 option with a 384-bit digest and a strong security margin.",
  },
  {
    id: "sha3-256",
    wasmId: 2,
    name: "SHA3-256",
    family: "SHA-3",
    bits: 256,
    bytes: 32,
    description:
      "A widely useful SHA-3 digest with a shorter, 64-character hexadecimal result.",
  },
  {
    id: "sha3-224",
    wasmId: 3,
    name: "SHA3-224",
    family: "SHA-3",
    bits: 224,
    bytes: 28,
    description:
      "The smallest standard SHA-3 digest offered here, useful when output length matters.",
  },
  {
    id: "sha-512",
    wasmId: 4,
    name: "SHA-512",
    family: "SHA-2",
    bits: 512,
    bytes: 64,
    description:
      "The established 512-bit member of the SHA-2 family, common in existing systems and tools.",
  },
  {
    id: "sha-384",
    wasmId: 5,
    name: "SHA-384",
    family: "SHA-2",
    bits: 384,
    bytes: 48,
    description:
      "A SHA-2 variant that balances a shorter digest with a broad compatibility footprint.",
  },
  {
    id: "sha-256",
    wasmId: 6,
    name: "SHA-256",
    family: "SHA-2",
    bits: 256,
    bytes: 32,
    description:
      "The most interoperable modern hash for checksums, fingerprints, and data integrity.",
  },
  {
    id: "blake3",
    wasmId: 7,
    name: "BLAKE3",
    family: "BLAKE",
    bits: 256,
    bytes: 32,
    description:
      "A newer, high-speed 256-bit hash designed for excellent software performance.",
  },
];

let enginePromise: Promise<HashEngine> | null = null;

async function loadEngine(): Promise<HashEngine> {
  if (!enginePromise) {
    enginePromise = (async () => {
      const response = await fetch("/hash_engine.wasm");
      if (!response.ok) {
        throw new Error(`Could not load hashing engine (${response.status})`);
      }

      const result = await WebAssembly.instantiate(await response.arrayBuffer());
      return result.instance.exports as unknown as HashEngine;
    })();
  }

  return enginePromise;
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(
    "",
  );
}

function runHash(engine: HashEngine, algorithm: Algorithm, value: string) {
  const input = new TextEncoder().encode(value);
  const inputCapacity = Math.max(1, input.length);
  const inputPointer = engine.allocate(inputCapacity);
  const outputPointer = engine.allocate(algorithm.bytes);

  if (!inputPointer || !outputPointer) {
    if (inputPointer) engine.deallocate(inputPointer, inputCapacity);
    if (outputPointer) engine.deallocate(outputPointer, algorithm.bytes);
    throw new Error("The browser could not allocate hashing memory.");
  }

  try {
    new Uint8Array(engine.memory.buffer, inputPointer, input.length).set(input);
    const digestLength = engine.hash(
      algorithm.wasmId,
      inputPointer,
      input.length,
      outputPointer,
      algorithm.bytes,
    );

    if (digestLength < 0) {
      throw new Error(`The hashing engine returned error ${digestLength}.`);
    }

    return bytesToHex(
      new Uint8Array(engine.memory.buffer, outputPointer, digestLength).slice(),
    );
  } finally {
    engine.deallocate(outputPointer, algorithm.bytes);
    engine.deallocate(inputPointer, inputCapacity);
  }
}

export function HashTool() {
  const [input, setInput] = useState("");
  const [selectedId, setSelectedId] = useState("sha3-512");
  const [engine, setEngine] = useState<HashEngine | null>(null);
  const [hashResult, setHashResult] = useState<{
    digest: string;
    input: string;
    algorithmId: string;
  } | null>(null);
  const [error, setError] = useState("");
  const [copyState, setCopyState] = useState<"idle" | "copied" | "failed">(
    "idle",
  );
  const outputRef = useRef<HTMLTextAreaElement>(null);

  const algorithm = useMemo(
    () =>
      algorithms.find((candidate) => candidate.id === selectedId) ??
      algorithms[0],
    [selectedId],
  );
  const byteCount = useMemo(
    () => new TextEncoder().encode(input).length,
    [input],
  );
  const characterCount = Array.from(input).length;
  const digest =
    hashResult?.input === input && hashResult.algorithmId === algorithm.id
      ? hashResult.digest
      : "";

  useEffect(() => {
    let active = true;

    loadEngine()
      .then((loadedEngine) => {
        if (active) setEngine(loadedEngine);
      })
      .catch((reason: unknown) => {
        if (active) {
          setError(
            reason instanceof Error
              ? reason.message
              : "The hashing engine could not start.",
          );
        }
      });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!engine) return;

    const timer = window.setTimeout(() => {
      try {
        setHashResult({
          digest: runHash(engine, algorithm, input),
          input,
          algorithmId: algorithm.id,
        });
        setError("");
      } catch (reason) {
        setHashResult(null);
        setError(
          reason instanceof Error ? reason.message : "Hashing could not finish.",
        );
      }
    }, 90);

    return () => window.clearTimeout(timer);
  }, [algorithm, engine, input]);

  async function copyDigest() {
    if (!digest) return;

    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(digest);
      } else {
        throw new Error("Clipboard API unavailable");
      }
      setCopyState("copied");
    } catch {
      const output = outputRef.current;
      if (!output) {
        setCopyState("failed");
        return;
      }

      output.focus();
      output.select();
      output.setSelectionRange(0, output.value.length);
      setCopyState(document.execCommand("copy") ? "copied" : "failed");
    }

    window.setTimeout(() => setCopyState("idle"), 1600);
  }

  return (
    <main className="page-shell">
      <nav className="topbar" aria-label="LocalHash">
        <a className="brand" href="#top" aria-label="LocalHash home">
          <span className="brand-mark" aria-hidden="true">
            LH
          </span>
          <span>LocalHash</span>
        </a>
        <div className="trust-badge">
          <span className="status-dot" aria-hidden="true" />
          Private by design
        </div>
      </nav>

      <section className="hero" id="top">
        <div className="eyebrow">
          <span>Rust</span>
          <span className="eyebrow-divider" aria-hidden="true" />
          <span>WebAssembly</span>
        </div>
        <h1>
          A fingerprint for
          <br />
          <span>whatever you type.</span>
        </h1>
        <p className="hero-copy">
          Generate reliable cryptographic hashes without sending a single
          character anywhere. Your browser does all the work.
        </p>
      </section>

      <section className="workspace" aria-label="Hash generator">
        <div className="panel input-panel">
          <div className="panel-heading">
            <div>
              <span className="step">01</span>
              <h2>Your text</h2>
            </div>
            <button
              className="text-button"
              type="button"
              onClick={() => {
                setInput("");
                setCopyState("idle");
              }}
              disabled={!input}
            >
              Clear
            </button>
          </div>
          <label className="sr-only" htmlFor="hash-input">
            Text to hash
          </label>
          <textarea
            id="hash-input"
            className="text-input"
            value={input}
            onChange={(event) => {
              setInput(event.target.value);
              setCopyState("idle");
            }}
            placeholder="Type or paste anything here…"
            spellCheck={false}
          />
          <div className="input-meta">
            <span>
              {characterCount.toLocaleString()} character
              {characterCount === 1 ? "" : "s"}
            </span>
            <span>
              {byteCount.toLocaleString()} UTF-8 byte{byteCount === 1 ? "" : "s"}
            </span>
          </div>
          <p className="microcopy">
            Spaces, capitalization, and line breaks all change the result.
          </p>
        </div>

        <div className="panel result-panel">
          <div className="panel-heading">
            <div>
              <span className="step">02</span>
              <h2>Digest</h2>
            </div>
            <div className={`engine-status ${engine ? "ready" : ""}`}>
              <span className="status-dot" aria-hidden="true" />
              {engine ? "WASM ready" : "Starting…"}
            </div>
          </div>

          <label className="field-label" htmlFor="algorithm">
            Algorithm
          </label>
          <div className="select-wrap">
            <select
              id="algorithm"
              value={selectedId}
              onChange={(event) => {
                setSelectedId(event.target.value);
                setCopyState("idle");
              }}
            >
              <optgroup label="SHA-3 family">
                {algorithms.slice(0, 4).map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="SHA-2 family">
                {algorithms.slice(4, 7).map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="BLAKE family">
                <option value="blake3">BLAKE3</option>
              </optgroup>
            </select>
            <span className="select-chevron" aria-hidden="true">
              ↓
            </span>
          </div>
          <p className="algorithm-description">{algorithm.description}</p>

          <div className="output-header">
            <label className="field-label" htmlFor="hash-output">
              Hexadecimal result
            </label>
            <span>
              {algorithm.bits} bits · {algorithm.bytes * 2} characters
            </span>
          </div>
          <textarea
            ref={outputRef}
            id="hash-output"
            className="hash-output"
            value={error || digest || (engine ? "Calculating…" : "Preparing the Rust engine…")}
            readOnly
            aria-label={`${algorithm.name} hexadecimal hash result`}
            aria-invalid={Boolean(error)}
          />
          <button
            className="copy-button"
            type="button"
            onClick={copyDigest}
            disabled={!digest || Boolean(error)}
          >
            <span aria-hidden="true">{copyState === "copied" ? "✓" : "▣"}</span>
            {copyState === "copied"
              ? "Copied to clipboard"
              : copyState === "failed"
                ? "Copy failed — select the result"
                : "Copy hash"}
          </button>
          <div className="sr-only" aria-live="polite">
            {copyState === "copied"
              ? "Hash copied to clipboard."
              : copyState === "failed"
                ? "Copy failed. Select the hash result and copy it manually."
                : ""}
          </div>
        </div>
      </section>

      <section className="assurances" aria-label="How LocalHash works">
        <article>
          <span className="assurance-icon" aria-hidden="true">
            01
          </span>
          <div>
            <h3>Stays on this device</h3>
            <p>No uploads, accounts, tracking, or network request for your text.</p>
          </div>
        </article>
        <article>
          <span className="assurance-icon" aria-hidden="true">
            02
          </span>
          <div>
            <h3>Exact UTF-8 bytes</h3>
            <p>Your input is hashed exactly as entered, including every space.</p>
          </div>
        </article>
        <article>
          <span className="assurance-icon" aria-hidden="true">
            03
          </span>
          <div>
            <h3>Built for integrity</h3>
            <p>A hash is a fingerprint, not encryption or password storage.</p>
          </div>
        </article>
      </section>

      <footer>
        <p>LocalHash · Rust-powered hashing in your browser</p>
        <p>One-way fingerprinting · Nothing stored</p>
      </footer>
    </main>
  );
}
