/* LocalVault Web Worker: owns the WASM instance and all cryptographic state. */

const decoder = new TextDecoder("utf-8", { fatal: true });
const encoder = new TextEncoder();

let wasm = null;

class CoreError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "CoreError";
    this.code = code;
  }
}

function requireWasm() {
  if (!wasm) {
    throw new CoreError(0, "The encryption engine is not ready.");
  }
  return wasm;
}

function allocate(bytes) {
  const core = requireWasm();
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (view.byteLength === 0) {
    return { pointer: 0, length: 0 };
  }
  const pointer = core.localvault_alloc(view.byteLength);
  if (pointer === 0) {
    throw new CoreError(0, "The browser could not allocate secure working memory.");
  }
  new Uint8Array(core.memory.buffer, pointer, view.byteLength).set(view);
  return { pointer, length: view.byteLength };
}

function release(region, erase = false) {
  if (!region || region.pointer === 0) return;
  const core = requireWasm();
  if (erase) {
    new Uint8Array(core.memory.buffer, region.pointer, region.length).fill(0);
  }
  core.localvault_dealloc(region.pointer, region.length);
}

function readResult(pointer) {
  const core = requireWasm();
  if (pointer === 0) {
    throw new CoreError(0, "The encryption engine did not return a result.");
  }

  let status;
  let payload;
  try {
    const prefix = new DataView(core.memory.buffer, pointer, 8);
    status = prefix.getUint32(0, true);
    const payloadLength = prefix.getUint32(4, true);
    const end = pointer + 8 + payloadLength;
    if (!Number.isSafeInteger(end) || end > core.memory.buffer.byteLength) {
      throw new CoreError(0, "The encryption engine returned an invalid result.");
    }
    payload = new Uint8Array(core.memory.buffer, pointer + 8, payloadLength).slice();
  } finally {
    core.localvault_result_free(pointer);
  }

  if (status !== 0) {
    let message = "The encryption engine rejected this operation.";
    try {
      message = decoder.decode(payload);
    } catch {
      // Keep the stable fallback; malformed errors are never security-sensitive.
    }
    throw new CoreError(status, message);
  }
  return payload;
}

function splitU64(value) {
  const number = typeof value === "bigint" ? value : BigInt(value);
  return [Number(number & 0xffff_ffffn), Number((number >> 32n) & 0xffff_ffffn)];
}

function readU64(view, offset) {
  return view.getBigUint64(offset, true);
}

function assertPayload(payload, minimum) {
  if (payload.byteLength < minimum) {
    throw new CoreError(0, "The encryption engine returned incomplete data.");
  }
}

async function initialize(wasmUrl, embeddedBytes) {
  if (embeddedBytes) {
    const { instance } = await WebAssembly.instantiate(embeddedBytes, {});
    wasm = instance.exports;
    return validateWasm();
  }

  const response = await fetch(wasmUrl, {
    cache: "no-store",
    credentials: "same-origin",
  });
  if (!response.ok) {
    throw new Error(`Unable to load the encryption engine (${response.status}).`);
  }

  let instance;
  try {
    ({ instance } = await WebAssembly.instantiateStreaming(response.clone(), {}));
  } catch {
    const bytes = await response.arrayBuffer();
    ({ instance } = await WebAssembly.instantiate(bytes, {}));
  }
  wasm = instance.exports;

  return validateWasm();
}

function validateWasm() {
  const required = [
    "memory",
    "localvault_abi_version",
    "localvault_alloc",
    "localvault_dealloc",
    "localvault_result_free",
    "localvault_encrypt_start",
    "localvault_encrypt_chunk",
    "localvault_inspect",
    "localvault_decrypt_start",
    "localvault_decrypt_chunk",
    "localvault_finish",
    "localvault_abort",
  ];
  if (required.some((name) => !(name in wasm)) || wasm.localvault_abi_version() !== 1) {
    wasm = null;
    throw new Error("This page and its encryption engine are different versions.");
  }
  return { version: 1 };
}

const handlers = {
  async init({ wasmUrl, wasmBytes }) {
    return { value: await initialize(wasmUrl, wasmBytes) };
  },

  async inspect({ bytes }) {
    let input;
    try {
      input = allocate(bytes);
      const payload = readResult(wasm.localvault_inspect(input.pointer, input.length));
      assertPayload(payload, 44);
      const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
      return {
        value: {
          headerLength: view.getUint32(0, true),
          memoryKiB: view.getUint32(4, true),
          iterations: view.getUint32(8, true),
          lanes: view.getUint32(12, true),
          chunkSize: view.getUint32(16, true),
          plaintextSize: readU64(view, 20),
          chunkCount: readU64(view, 28),
          expectedContainerSize: readU64(view, 36),
        },
      };
    } finally {
      release(input);
    }
  },

  async encryptStart({ password, filename, mimeType, size, modified, salt, noncePrefix }) {
    const passwordBytes = new Uint8Array(password);
    const regions = {};
    const [sizeLow, sizeHigh] = splitU64(size);
    const [modifiedLow, modifiedHigh] = splitU64(modified);
    try {
      regions.password = allocate(passwordBytes);
      regions.filename = allocate(encoder.encode(filename));
      regions.mime = allocate(encoder.encode(mimeType));
      regions.salt = allocate(salt);
      regions.nonce = allocate(noncePrefix);
      const payload = readResult(
        wasm.localvault_encrypt_start(
          regions.password.pointer,
          regions.password.length,
          regions.filename.pointer,
          regions.filename.length,
          regions.mime.pointer,
          regions.mime.length,
          sizeLow,
          sizeHigh,
          modifiedLow,
          modifiedHigh,
          regions.salt.pointer,
          regions.salt.length,
          regions.nonce.pointer,
          regions.nonce.length,
        ),
      );
      assertPayload(payload, 4);
      const handle = new DataView(payload.buffer, payload.byteOffset, 4).getUint32(0, true);
      const header = payload.slice(4).buffer;
      return { value: { handle, header }, transfer: [header] };
    } finally {
      passwordBytes.fill(0);
      release(regions.password, true);
      release(regions.filename);
      release(regions.mime);
      release(regions.salt, true);
      release(regions.nonce, true);
    }
  },

  async encryptChunk({ handle, index, bytes }) {
    const plaintext = new Uint8Array(bytes);
    let input;
    const [indexLow, indexHigh] = splitU64(index);
    try {
      input = allocate(plaintext);
      const payload = readResult(
        wasm.localvault_encrypt_chunk(
          handle,
          indexLow,
          indexHigh,
          input.pointer,
          input.length,
        ),
      );
      const output = payload.buffer;
      return { value: output, transfer: [output] };
    } finally {
      plaintext.fill(0);
      release(input, true);
    }
  },

  async decryptStart({ password, header }) {
    const passwordBytes = new Uint8Array(password);
    let passwordRegion;
    let headerRegion;
    try {
      passwordRegion = allocate(passwordBytes);
      headerRegion = allocate(header);
      const payload = readResult(
        wasm.localvault_decrypt_start(
          passwordRegion.pointer,
          passwordRegion.length,
          headerRegion.pointer,
          headerRegion.length,
        ),
      );
      assertPayload(payload, 40);
      const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
      const filenameLength = view.getUint16(36, true);
      const mimeLength = view.getUint16(38, true);
      if (40 + filenameLength + mimeLength !== payload.byteLength) {
        throw new CoreError(11, "The encrypted file metadata is invalid.");
      }
      const filename = decoder.decode(payload.subarray(40, 40 + filenameLength));
      const mimeType = decoder.decode(payload.subarray(40 + filenameLength));
      return {
        value: {
          handle: view.getUint32(0, true),
          headerLength: view.getUint32(4, true),
          chunkSize: view.getUint32(8, true),
          plaintextSize: readU64(view, 12),
          chunkCount: readU64(view, 20),
          modified: readU64(view, 28),
          filename,
          mimeType,
        },
      };
    } finally {
      passwordBytes.fill(0);
      release(passwordRegion, true);
      release(headerRegion);
    }
  },

  async decryptChunk({ handle, index, bytes }) {
    let input;
    const [indexLow, indexHigh] = splitU64(index);
    try {
      input = allocate(bytes);
      const payload = readResult(
        wasm.localvault_decrypt_chunk(
          handle,
          indexLow,
          indexHigh,
          input.pointer,
          input.length,
        ),
      );
      const output = payload.buffer;
      return { value: output, transfer: [output] };
    } finally {
      release(input);
    }
  },

  async finish({ handle }) {
    readResult(wasm.localvault_finish(handle));
    return { value: null };
  },

  async abort({ handle }) {
    if (wasm && handle) wasm.localvault_abort(handle);
    return { value: null };
  },
};

self.addEventListener("message", async (event) => {
  const { id, operation, data } = event.data ?? {};
  if (!Number.isInteger(id)) return;
  if (!Object.hasOwn(handlers, operation)) {
    self.postMessage({
      id,
      ok: false,
      error: { code: 0, message: "This page and its encryption worker are different versions." },
    });
    return;
  }

  try {
    const { value, transfer = [] } = await handlers[operation](data ?? {});
    self.postMessage({ id, ok: true, value }, transfer);
  } catch (error) {
    self.postMessage({
      id,
      ok: false,
      error: {
        code: Number.isInteger(error?.code) ? error.code : 0,
        message: error instanceof Error ? error.message : "The encryption engine failed.",
      },
    });
  }
});
