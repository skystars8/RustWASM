const EMBEDDED_ASSETS = globalThis.__LOCALVAULT_EMBEDDED__ ?? null;
const WASM_URL = EMBEDDED_ASSETS ? null : new URL("./localvault.wasm", document.baseURI).href;
const WORKER_URL = EMBEDDED_ASSETS ? null : new URL("./worker.js", document.baseURI);
const FIXED_HEADER_LENGTH = 80;
const FORMAT_EXTENSION = ".lvault";
const CHUNK_TAG_LENGTH = 16;
const MEMORY_OUTPUT_LIMIT = 256 * 1024 * 1024;
const DIRECT_SAVE_RECOMMENDATION = 64 * 1024 * 1024;
const MAX_PASSWORD_BYTES = 1024;

const elements = Object.fromEntries(
  [
    "engine-status",
    "encrypt-tab",
    "decrypt-tab",
    "vault-form",
    "file-input",
    "drop-zone",
    "drop-title",
    "drop-copy",
    "file-summary",
    "file-name",
    "file-size",
    "remove-file",
    "mode-suggestion",
    "switch-to-decrypt",
    "password-label",
    "password",
    "confirm-group",
    "confirm-password",
    "password-help",
    "strength",
    "strength-label",
    "direct-save-row",
    "direct-save",
    "submit-button",
    "submit-label",
    "progress-panel",
    "progress-title",
    "progress-copy",
    "progress-bar",
    "cancel-button",
    "error-panel",
    "error-message",
    "retry-engine",
    "result-panel",
    "result-title",
    "result-copy",
    "result-name",
    "download-again",
    "reset-button",
    "security-details",
  ].map((id) => [id, document.getElementById(id)]),
);

const state = {
  mode: "encrypt",
  file: null,
  busy: false,
  cancelled: false,
  engineReady: false,
  download: null,
};

class WorkerError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "WorkerError";
    this.code = code;
  }
}

class CancelledError extends Error {
  constructor() {
    super("Operation cancelled.");
    this.name = "CancelledError";
  }
}

class VaultEngine {
  constructor() {
    this.worker = null;
    this.workerObjectUrl = null;
    this.pending = new Map();
    this.nextId = 1;
  }

  async start() {
    this.stop(new Error("The encryption engine restarted."));
    let worker;
    if (EMBEDDED_ASSETS) {
      this.workerObjectUrl = URL.createObjectURL(
        new Blob([EMBEDDED_ASSETS.workerSource], { type: "text/javascript" }),
      );
      worker = new Worker(this.workerObjectUrl, { name: "localvault-crypto" });
    } else {
      worker = new Worker(WORKER_URL, { type: "module", name: "localvault-crypto" });
    }
    this.worker = worker;
    worker.addEventListener("message", (event) => this.onMessage(event));
    worker.addEventListener("error", () => {
      const error = new WorkerError(0, "The encryption engine stopped unexpectedly.");
      this.stop(error);
      setEngineStatus("error", "Encryption engine unavailable");
      if (!state.busy) {
        showError(error);
        byId("retry-engine").hidden = false;
      }
    });
    worker.addEventListener("messageerror", () => {
      const error = new WorkerError(0, "The browser could not read the encryption engine response.");
      this.stop(error);
      setEngineStatus("error", "Encryption engine unavailable");
      if (!state.busy) {
        showError(error);
        byId("retry-engine").hidden = false;
      }
    });
    if (EMBEDDED_ASSETS) {
      const wasmBytes = decodeBase64(EMBEDDED_ASSETS.wasmBase64);
      await this.call("init", { wasmBytes }, [wasmBytes]);
    } else {
      await this.call("init", { wasmUrl: WASM_URL });
    }
  }

  call(operation, data = {}, transfer = []) {
    if (!this.worker) {
      return Promise.reject(new WorkerError(0, "The encryption engine is not running."));
    }
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try {
        this.worker.postMessage({ id, operation, data }, transfer);
      } catch (error) {
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  onMessage(event) {
    const { id, ok, value, error } = event.data ?? {};
    const request = this.pending.get(id);
    if (!request) return;
    this.pending.delete(id);
    if (ok) {
      request.resolve(value);
    } else {
      request.reject(new WorkerError(error?.code ?? 0, error?.message ?? "Operation failed."));
    }
  }

  stop(reason = new CancelledError()) {
    if (this.worker) this.worker.terminate();
    this.worker = null;
    if (this.workerObjectUrl) URL.revokeObjectURL(this.workerObjectUrl);
    this.workerObjectUrl = null;
    for (const request of this.pending.values()) request.reject(reason);
    this.pending.clear();
    state.engineReady = false;
    updateSubmitState();
  }
}

class OutputSink {
  constructor(writable = null, handle = null) {
    this.writable = writable;
    this.handle = handle;
    this.parts = writable ? null : [];
    this.closed = false;
  }

  get direct() {
    return Boolean(this.writable);
  }

  async write(bytes) {
    if (this.closed) throw new Error("The output has already been closed.");
    if (this.writable) {
      try {
        await this.writable.write(bytes);
      } finally {
        wipeBytes(bytes);
      }
    } else {
      this.parts.push(bytes);
    }
  }

  async complete(filename, mimeType) {
    if (this.closed) throw new Error("The output has already been closed.");
    if (this.writable) {
      await this.writable.close();
      this.closed = true;
      return { direct: true, filename: this.handle?.name || filename, size: null };
    }
    let url;
    try {
      const blob = new Blob(this.parts, { type: safeMimeType(mimeType) });
      for (const part of this.parts) wipeBytes(part);
      this.parts = [];
      url = URL.createObjectURL(blob);
      triggerDownload(url, filename);
      this.closed = true;
      return { direct: false, filename, size: blob.size, url };
    } catch (error) {
      if (url) URL.revokeObjectURL(url);
      throw error;
    }
  }

  async abort() {
    for (const part of this.parts ?? []) wipeBytes(part);
    this.parts = [];
    if (this.closed) return;
    if (this.writable) {
      try {
        await this.writable.abort();
      } catch {
        // A stream that already failed may reject abort; there is nothing else to expose.
      }
    }
    this.closed = true;
  }
}

const engine = new VaultEngine();
const encoder = new TextEncoder();

function byId(id) {
  const element = elements[id];
  if (!element) throw new Error(`Missing required element: ${id}`);
  return element;
}

function decodeBase64(value) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes.buffer;
}

function formatBytes(bytes) {
  if (bytes === 0) return "0 bytes";
  const units = ["bytes", "KB", "MB", "GB", "TB"];
  const exponent = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** exponent;
  const digits = exponent === 0 || value >= 10 ? 0 : 1;
  return `${value.toFixed(digits)} ${units[exponent]}`;
}

function formatPercent(value) {
  return `${Math.min(100, Math.round(value * 100))}%`;
}

function formatOutputEstimate(size) {
  return size === null ? "" : ` · ${formatBytes(size)}`;
}

function codePointLength(value) {
  return Array.from(value).length;
}

function isEncryptedName(name) {
  return name.toLocaleLowerCase().endsWith(FORMAT_EXTENSION);
}

function encryptedFilename(name) {
  const safe = sanitizeFilename(name, "encrypted-file");
  const maxBase = 180 - FORMAT_EXTENSION.length;
  return `${Array.from(safe).slice(0, maxBase).join("")}${FORMAT_EXTENSION}`;
}

function fallbackDecryptedFilename(name) {
  if (isEncryptedName(name)) {
    return sanitizeFilename(name.slice(0, -FORMAT_EXTENSION.length), "decrypted-file");
  }
  return sanitizeFilename(`${name}.decrypted`, "decrypted-file");
}

function sanitizeFilename(name, fallback) {
  const cleaned = String(name)
    .replace(/[\u0000-\u001f\u007f/\\]/g, "_")
    .replace(/[. ]+$/g, "")
    .trim();
  if (!cleaned || cleaned === "." || cleaned === "..") return fallback;
  return Array.from(cleaned).slice(0, 180).join("");
}

function safeMimeType(type) {
  return /^[\w!#$&^.+-]+\/[\w!#$&^.+-]+$/u.test(type || "")
    ? type
    : "application/octet-stream";
}

function triggerDownload(url, filename) {
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = "noopener";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
}

function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

function revokeDownload() {
  if (state.download?.url) URL.revokeObjectURL(state.download.url);
  state.download = null;
}

function wipeBytes(bytes) {
  try {
    const view = bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : new Uint8Array(bytes.buffer);
    view.fill(0);
  } catch {
    // A transferred/detached buffer no longer contains bytes in this realm.
  }
}

function clearMessages() {
  byId("error-panel").hidden = true;
  byId("result-panel").hidden = true;
  byId("retry-engine").hidden = true;
}

function showError(error) {
  let message;
  switch (error?.code) {
    case 1:
      message = "We couldn’t decrypt this file. The passphrase may be incorrect, or the file may be damaged.";
      break;
    case 2:
      message = "This isn’t a supported LocalVault file.";
      break;
    case 3:
      message = "This file was created with a newer or unsupported format version.";
      break;
    case 4:
      message = "Use a passphrase with at least 12 characters.";
      break;
    case 10:
      message = "This file is too large for the LocalVault format.";
      break;
    case 11:
      message = "The encrypted file contains invalid protected metadata.";
      break;
    default:
      message = error instanceof Error ? error.message : "Something went wrong. Please try again.";
  }
  byId("error-message").textContent = message;
  byId("retry-engine").hidden = true;
  byId("error-panel").hidden = false;
  byId("error-panel").focus();
}

function setEngineStatus(kind, text) {
  const status = byId("engine-status");
  status.dataset.state = kind;
  const label = status.querySelector("span:last-child");
  if (label) label.textContent = text;
  else status.textContent = text;
}

async function initializeEngine() {
  state.engineReady = false;
  setEngineStatus("loading", "Starting encryption engine…");
  byId("submit-button").disabled = true;
  try {
    await engine.start();
    state.engineReady = true;
    setEngineStatus("ready", "Encryption engine ready");
  } catch (error) {
    engine.stop(error);
    setEngineStatus("error", "Encryption engine unavailable");
    showError(
      new Error(
        EMBEDDED_ASSETS
          ? "The embedded encryption engine couldn’t start. Try reopening this file in a current browser."
          : "The encryption engine couldn’t start. Serve this page over HTTPS or localhost, then try again.",
      ),
    );
    byId("retry-engine").hidden = false;
  } finally {
    updateSubmitState();
  }
}

function setMode(mode, { preserveFile = false } = {}) {
  if (state.busy || !["encrypt", "decrypt"].includes(mode)) return;
  state.mode = mode;
  for (const candidate of ["encrypt", "decrypt"]) {
    const tab = byId(`${candidate}-tab`);
    const selected = candidate === mode;
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
    tab.dataset.active = String(selected);
  }
  byId("confirm-group").hidden = mode !== "encrypt";
  byId("strength").hidden = mode !== "encrypt";
  byId("password-label").textContent = mode === "encrypt" ? "Create a passphrase" : "Enter the passphrase";
  byId("password-help").textContent =
    mode === "encrypt"
      ? "Use 12 or more characters. Your passphrase cannot be recovered."
      : "Passphrases are exact: spaces and capitalization matter.";
  byId("drop-title").textContent = mode === "encrypt" ? "Drop any file here" : "Drop an encrypted file here";
  byId("drop-copy").textContent = mode === "encrypt" ? "or choose a file" : "or choose a .lvault file";
  byId("submit-label").textContent = mode === "encrypt" ? "Encrypt & save" : "Decrypt & save";
  byId("file-input").accept = mode === "decrypt" ? ".lvault,application/vnd.localvault" : "";
  byId("password").autocomplete = mode === "encrypt" ? "new-password" : "current-password";
  byId("password").value = "";
  byId("confirm-password").value = "";
  resetPasswordVisibility();
  updateStrength();
  clearMessages();
  revokeDownload();
  if (!preserveFile) clearFile();
  else renderFile();
  byId("mode-suggestion").hidden = true;
  updateSubmitState();
}

function setFile(file) {
  if (!(file instanceof File) || state.busy) return;
  state.file = file;
  clearMessages();
  revokeDownload();
  renderFile();
  const suggestDecrypt = state.mode === "encrypt" && isEncryptedName(file.name);
  byId("mode-suggestion").hidden = !suggestDecrypt;
  if (byId("direct-save-row").hidden === false) {
    byId("direct-save").checked = file.size >= DIRECT_SAVE_RECOMMENDATION;
  }
  updateSubmitState();
}

function clearFile() {
  state.file = null;
  byId("file-input").value = "";
  renderFile();
  updateSubmitState();
}

function renderFile() {
  const hasFile = Boolean(state.file);
  byId("drop-zone").hidden = hasFile;
  byId("file-summary").hidden = !hasFile;
  if (hasFile) {
    byId("file-name").textContent = state.file.name;
    byId("file-name").title = state.file.name;
    byId("file-size").textContent = `${formatBytes(state.file.size)} · ${state.file.type || "Unknown type"}`;
  } else {
    byId("file-name").textContent = "";
    byId("file-size").textContent = "";
    byId("mode-suggestion").hidden = true;
  }
}

function updateSubmitState() {
  byId("submit-button").disabled = state.busy || !state.engineReady || !state.file;
}

function setBusy(busy) {
  state.busy = busy;
  for (const control of document.querySelectorAll("button, input")) {
    if (control.id === "cancel-button") continue;
    control.disabled = busy;
  }
  byId("cancel-button").disabled = !busy;
  byId("progress-panel").hidden = !busy;
  document.body.classList.toggle("is-busy", busy);
  updateSubmitState();
}

function setProgress(title, copy, value = null) {
  byId("progress-title").textContent = title;
  byId("progress-copy").textContent = copy;
  const progress = byId("progress-bar");
  if (value === null) progress.removeAttribute("value");
  else progress.value = Math.max(0, Math.min(1, value));
}

function updateStrength() {
  const meter = byId("strength");
  const label = byId("strength-label");
  const password = byId("password").value;
  const length = codePointLength(password);
  let score = 0;
  if (length >= 12) score = 1;
  if (length >= 16) score = 2;
  if (length >= 20) score = 3;
  if (length >= 28) score = 4;
  meter.dataset.score = String(score);
  meter.setAttribute("aria-valuenow", String(score));
  const labels = ["Use at least 12 characters", "Good", "Strong", "Very strong", "Excellent passphrase length"];
  label.textContent = labels[score];
}

function resetPasswordVisibility() {
  for (const input of [byId("password"), byId("confirm-password")]) input.type = "password";
  document.querySelectorAll("[data-password-toggle]").forEach((button) => {
    button.setAttribute("aria-pressed", "false");
    button.setAttribute("aria-label", "Show passphrase");
    const label = button.querySelector("span");
    if (label) label.textContent = "Show";
  });
}

function validateForm() {
  clearMessages();
  const file = state.file;
  if (!file) {
    showError(new Error("Choose a file to continue."));
    byId("file-input").focus();
    return null;
  }
  if (!Number.isSafeInteger(file.size)) {
    showError(new Error("This file is too large for this browser."));
    return null;
  }

  const passwordInput = byId("password");
  const password = passwordInput.value;
  const passwordBytes = encoder.encode(password);
  if (!password) {
    passwordInput.setAttribute("aria-invalid", "true");
    showError(new Error("Enter your passphrase."));
    passwordInput.focus();
    return null;
  }
  if (passwordBytes.byteLength > MAX_PASSWORD_BYTES) {
    passwordInput.setAttribute("aria-invalid", "true");
    passwordBytes.fill(0);
    showError(new Error("The passphrase must be no more than 1,024 UTF-8 bytes."));
    passwordInput.focus();
    return null;
  }
  if (state.mode === "encrypt" && codePointLength(password) < 12) {
    passwordInput.setAttribute("aria-invalid", "true");
    passwordBytes.fill(0);
    showError(new Error("Use a passphrase with at least 12 characters."));
    passwordInput.focus();
    return null;
  }
  passwordInput.removeAttribute("aria-invalid");

  if (state.mode === "encrypt" && byId("confirm-password").value !== password) {
    byId("confirm-password").setAttribute("aria-invalid", "true");
    passwordBytes.fill(0);
    showError(new Error("The passphrases do not match."));
    byId("confirm-password").focus();
    return null;
  }
  byId("confirm-password").removeAttribute("aria-invalid");

  if (encoder.encode(file.name).byteLength > 1024) {
    passwordBytes.fill(0);
    showError(new Error("This filename is too long to protect safely."));
    return null;
  }
  return { file, passwordBytes };
}

function supportsDirectSave() {
  return window.isSecureContext && typeof window.showSaveFilePicker === "function";
}

async function createSink(suggestedName, encrypted) {
  const direct = supportsDirectSave() && byId("direct-save").checked;
  if (!direct) return new OutputSink();
  const handle = await window.showSaveFilePicker({
    suggestedName,
    excludeAcceptAllOption: false,
    types: encrypted
      ? [
          {
            description: "LocalVault encrypted file",
            accept: { "application/vnd.localvault": [FORMAT_EXTENSION] },
          },
        ]
      : undefined,
  });
  const writable = await handle.createWritable({ keepExistingData: false });
  return new OutputSink(writable, handle);
}

function checkMemoryFallback(estimatedSize, direct) {
  if (!direct && estimatedSize > MEMORY_OUTPUT_LIMIT) {
    throw new Error(
      "This output is too large to hold safely in browser memory. Use direct-to-file saving in a supported browser over HTTPS or localhost.",
    );
  }
}

async function encryptFile(file, passwordBytes, sink) {
  const chunkCount = file.size === 0 ? 1 : Math.ceil(file.size / (4 * 1024 * 1024));
  const estimatedSize = file.size + chunkCount * CHUNK_TAG_LENGTH + 4096;
  checkMemoryFallback(estimatedSize, sink.direct);
  setProgress("Strengthening your passphrase…", "This memory-hard step makes guessing attacks more expensive.");

  const salt = randomBytes(16);
  const noncePrefix = randomBytes(16);
  // Transfer a short-lived copy; keep the caller's view attached so its bytes
  // can still be overwritten in `finally` on every browser.
  const passwordBuffer = passwordBytes.slice().buffer;
  let session;
  try {
    session = await engine.call(
      "encryptStart",
      {
        password: passwordBuffer,
        filename: file.name,
        mimeType: file.type || "application/octet-stream",
        size: BigInt(file.size),
        modified: BigInt(Math.max(0, file.lastModified || 0)),
        salt: salt.buffer,
        noncePrefix: noncePrefix.buffer,
      },
      [passwordBuffer, salt.buffer, noncePrefix.buffer],
    );
    await sink.write(session.header);

    const chunkSize = 4 * 1024 * 1024;
    for (let index = 0; index < chunkCount; index += 1) {
      const start = index * chunkSize;
      const end = Math.min(file.size, start + chunkSize);
      const plaintext = await file.slice(start, end).arrayBuffer();
      const ciphertext = await engine.call(
        "encryptChunk",
        { handle: session.handle, index: BigInt(index), bytes: plaintext },
        [plaintext],
      );
      await sink.write(ciphertext);
      const progress = (index + 1) / chunkCount;
      setProgress("Encrypting your file…", `${formatPercent(progress)} complete · Keep this tab open.`, progress);
    }
    await engine.call("finish", { handle: session.handle });
    session.handle = 0;
  } finally {
    passwordBytes.fill(0);
    if (session?.handle) engine.call("abort", { handle: session.handle }).catch(() => {});
  }

  setProgress("Preparing your file…", "Finalizing the protected output.", 1);
  byId("cancel-button").disabled = true;
  const outputName = encryptedFilename(file.name);
  return sink.complete(outputName, "application/vnd.localvault");
}

async function decryptFile(file, passwordBytes, sink) {
  checkMemoryFallback(file.size, sink.direct);
  setProgress("Checking the encrypted file…", "Validating its format before processing the passphrase.");
  if (file.size < FIXED_HEADER_LENGTH) {
    passwordBytes.fill(0);
    throw new WorkerError(2, "This is not a supported LocalVault file.");
  }

  const prefix = await file.slice(0, FIXED_HEADER_LENGTH).arrayBuffer();
  const inspection = await engine.call("inspect", { bytes: prefix }, [prefix]);
  if (inspection.expectedContainerSize !== BigInt(file.size)) {
    passwordBytes.fill(0);
    throw new WorkerError(2, "The encrypted file has been truncated or has trailing data.");
  }
  if (inspection.headerLength > file.size) {
    passwordBytes.fill(0);
    throw new WorkerError(2, "The encrypted header is incomplete.");
  }

  setProgress("Strengthening your passphrase…", "Checking the passphrase against the authenticated header.");
  const header = await file.slice(0, inspection.headerLength).arrayBuffer();
  const passwordBuffer = passwordBytes.slice().buffer;
  let session;
  try {
    session = await engine.call(
      "decryptStart",
      { password: passwordBuffer, header },
      [passwordBuffer, header],
    );
    const safeName = sanitizeFilename(session.filename, fallbackDecryptedFilename(file.name));
    let offset = session.headerLength;
    const chunkCount = Number(session.chunkCount);
    if (!Number.isSafeInteger(chunkCount) || chunkCount < 1) {
      throw new WorkerError(2, "The encrypted file has an invalid chunk count.");
    }

    for (let index = 0; index < chunkCount; index += 1) {
      const isLast = index + 1 === chunkCount;
      const consumed = BigInt(index) * BigInt(session.chunkSize);
      const plaintextLength = isLast
        ? Number(session.plaintextSize - consumed)
        : session.chunkSize;
      const ciphertextLength = plaintextLength + CHUNK_TAG_LENGTH;
      const ciphertext = await file.slice(offset, offset + ciphertextLength).arrayBuffer();
      if (ciphertext.byteLength !== ciphertextLength) {
        throw new WorkerError(1, "The encrypted file is damaged.");
      }
      const plaintext = await engine.call(
        "decryptChunk",
        { handle: session.handle, index: BigInt(index), bytes: ciphertext },
        [ciphertext],
      );
      await sink.write(plaintext);
      offset += ciphertextLength;
      const progress = (index + 1) / chunkCount;
      setProgress("Decrypting your file…", `${formatPercent(progress)} complete · Keep this tab open.`, progress);
    }
    if (offset !== file.size) throw new WorkerError(1, "The encrypted file contains trailing data.");
    await engine.call("finish", { handle: session.handle });
    session.handle = 0;
    setProgress("Preparing your file…", "Finalizing the authenticated output.", 1);
    byId("cancel-button").disabled = true;
    return sink.complete(safeName, session.mimeType);
  } finally {
    passwordBytes.fill(0);
    if (session?.handle) engine.call("abort", { handle: session.handle }).catch(() => {});
  }
}

function showSuccess(download, mode) {
  revokeDownload();
  state.download = download;
  byId("result-title").textContent =
    mode === "encrypt" ? "Your encrypted file is ready." : "Your decrypted file is ready.";
  byId("result-copy").textContent = download.direct
    ? "Saved directly to the location you selected."
    : "The download has started. You can download it again below.";
  byId("result-name").textContent = `${download.filename}${formatOutputEstimate(download.size)}`;
  byId("download-again").hidden = download.direct;
  byId("reset-button").textContent = mode === "encrypt" ? "Encrypt another file" : "Decrypt another file";
  byId("result-panel").hidden = false;
  byId("result-title").focus();
}

async function handleSubmit(event) {
  event.preventDefault();
  if (state.busy || !state.engineReady) return;
  const validated = validateForm();
  if (!validated) return;
  resetPasswordVisibility();

  const mode = state.mode;
  const suggestedName =
    mode === "encrypt" ? encryptedFilename(validated.file.name) : fallbackDecryptedFilename(validated.file.name);
  let sink;
  try {
    // The picker must run directly from the submit gesture, before any KDF work.
    sink = await createSink(suggestedName, mode === "encrypt");
  } catch (error) {
    validated.passwordBytes.fill(0);
    if (error?.name !== "AbortError") showError(error);
    return;
  }

  state.cancelled = false;
  byId("password").value = "";
  byId("confirm-password").value = "";
  updateStrength();
  clearMessages();
  revokeDownload();
  setBusy(true);
  setProgress("Reading your file…", "Keep this tab open while LocalVault works.");
  try {
    const download =
      mode === "encrypt"
        ? await encryptFile(validated.file, validated.passwordBytes, sink)
        : await decryptFile(validated.file, validated.passwordBytes, sink);
    byId("password").value = "";
    byId("confirm-password").value = "";
    resetPasswordVisibility();
    updateStrength();
    showSuccess(download, mode);
  } catch (error) {
    await sink.abort();
    if (!(error instanceof CancelledError) && !state.cancelled) showError(error);
  } finally {
    validated.passwordBytes.fill(0);
    // A fresh worker discards the entire WASM linear memory, including KDF
    // working pages that cannot otherwise be returned to the browser.
    engine.stop(new Error("The completed encryption worker was recycled."));
    setBusy(false);
    byId("progress-panel").hidden = true;
    if (!document.hidden) await initializeEngine();
    else setEngineStatus("loading", "Encryption engine paused");
    if (state.cancelled) byId("password").focus();
  }
}

function cancelOperation() {
  if (!state.busy) return;
  state.cancelled = true;
  engine.stop(new CancelledError());
  byId("progress-title").textContent = "Cancelling…";
  byId("progress-copy").textContent = "Discarding partial output and clearing working memory.";
}

function togglePassword(button) {
  const input = document.getElementById(button.dataset.target);
  if (!input) return;
  const showing = input.type === "text";
  input.type = showing ? "password" : "text";
  button.setAttribute("aria-pressed", String(!showing));
  button.setAttribute("aria-label", showing ? "Show passphrase" : "Hide passphrase");
  const label = button.querySelector("span");
  if (label) label.textContent = showing ? "Show" : "Hide";
  input.focus();
}

function setupEvents() {
  byId("encrypt-tab").addEventListener("click", () => setMode("encrypt"));
  byId("decrypt-tab").addEventListener("click", () => setMode("decrypt"));
  for (const tab of [byId("encrypt-tab"), byId("decrypt-tab")]) {
    tab.addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
      event.preventDefault();
      const next = state.mode === "encrypt" ? "decrypt" : "encrypt";
      setMode(next);
      byId(`${next}-tab`).focus();
    });
  }

  byId("file-input").addEventListener("change", (event) => setFile(event.target.files?.[0]));
  byId("remove-file").addEventListener("click", clearFile);
  byId("switch-to-decrypt").addEventListener("click", () => setMode("decrypt", { preserveFile: true }));
  byId("vault-form").addEventListener("submit", handleSubmit);
  byId("cancel-button").addEventListener("click", cancelOperation);
  byId("retry-engine").addEventListener("click", () => {
    clearMessages();
    initializeEngine();
  });
  byId("password").addEventListener("input", updateStrength);
  byId("password").addEventListener("input", () => byId("password").removeAttribute("aria-invalid"));
  byId("confirm-password").addEventListener("input", () =>
    byId("confirm-password").removeAttribute("aria-invalid"),
  );
  document.querySelectorAll("[data-password-toggle]").forEach((button) => {
    button.addEventListener("click", () => togglePassword(button));
  });

  const dropZone = byId("drop-zone");
  for (const eventName of ["dragenter", "dragover"]) {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      if (!state.busy) dropZone.classList.add("is-dragging");
    });
  }
  for (const eventName of ["dragleave", "drop"]) {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.remove("is-dragging");
    });
  }
  dropZone.addEventListener("drop", (event) => setFile(event.dataTransfer?.files?.[0]));

  byId("download-again").addEventListener("click", () => {
    if (state.download?.url) triggerDownload(state.download.url, state.download.filename);
  });
  byId("reset-button").addEventListener("click", () => {
    revokeDownload();
    clearFile();
    clearMessages();
    byId("password").focus();
  });
  window.addEventListener("beforeunload", (event) => {
    if (!state.busy) return;
    event.preventDefault();
    event.returnValue = "";
  });
  window.addEventListener("pagehide", () => {
    revokeDownload();
    engine.stop();
  });
  window.addEventListener("pageshow", () => {
    if (!state.download) byId("result-panel").hidden = true;
    if (!engine.worker && !state.busy) initializeEngine();
  });
}

function boot() {
  // A missing required element is a build error; fail visibly rather than halfway through a file.
  for (const id of Object.keys(elements)) byId(id);
  const direct = supportsDirectSave();
  byId("direct-save-row").hidden = !direct;
  setupEvents();
  setMode("encrypt");
  renderFile();
  initializeEngine();
}

boot();
