use sha2::{Digest, Sha256};
use std::{env, fs, path::Path};

const EXTERNAL_CSP: &str = "default-src 'none'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self'; connect-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; manifest-src 'self'";

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let output = env::args()
        .nth(1)
        .unwrap_or_else(|| "localvault.html".to_owned());
    let html = fs::read_to_string("web/index.html")?;
    let css = fs::read_to_string("web/styles.css")?;
    let app = fs::read_to_string("web/app.js")?;
    let worker = fs::read_to_string("web/worker.js")?;
    let wasm = fs::read("target/wasm32-unknown-unknown/release/localvault.wasm")?;

    let style_content = format!("\n{css}\n");
    let style_tag = format!("<style>{style_content}</style>");
    let embedded_config = format!(
        "globalThis.__LOCALVAULT_EMBEDDED__ = Object.freeze({{ workerSource: {}, wasmBase64: {} }});",
        javascript_string(&worker),
        javascript_string(&base64(&wasm)),
    );
    let script_content = format!("\n{embedded_config}\n{app}\n");
    let script_tag = format!("<script>{script_content}</script>");
    let standalone_csp = format!(
        "default-src 'none'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; script-src 'sha256-{}' 'wasm-unsafe-eval' blob:; worker-src blob:; connect-src 'none'; style-src 'sha256-{}'; img-src data:; font-src 'none'; manifest-src 'none'",
        csp_hash(&script_content),
        csp_hash(&style_content),
    );

    let bundled = replace_once(&html, EXTERNAL_CSP, &standalone_csp)?;
    let bundled = replace_once(
        &bundled,
        "<link rel=\"stylesheet\" href=\"styles.css\">",
        &style_tag,
    )?;
    let bundled = replace_once(
        &bundled,
        "<script type=\"module\" src=\"app.js\"></script>",
        &script_tag,
    )?;
    if bundled.contains("<script type=\"module\" src=")
        || bundled.contains("<link rel=\"stylesheet\" href=")
    {
        return Err("the standalone bundle still contains an external executable asset".into());
    }

    fs::write(Path::new(&output), bundled)?;
    println!("wrote {output} ({} bytes)", fs::metadata(&output)?.len());
    Ok(())
}

fn replace_once(source: &str, needle: &str, replacement: &str) -> Result<String, &'static str> {
    if source.matches(needle).count() != 1 {
        return Err("a standalone bundle marker was missing or duplicated");
    }
    Ok(source.replacen(needle, replacement, 1))
}

fn javascript_string(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len() + 2);
    escaped.push('"');
    for character in value.chars() {
        match character {
            '"' => escaped.push_str("\\\""),
            '\\' => escaped.push_str("\\\\"),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            '\u{08}' => escaped.push_str("\\b"),
            '\u{0c}' => escaped.push_str("\\f"),
            '<' => escaped.push_str("\\u003c"),
            '>' => escaped.push_str("\\u003e"),
            '&' => escaped.push_str("\\u0026"),
            '\u{2028}' => escaped.push_str("\\u2028"),
            '\u{2029}' => escaped.push_str("\\u2029"),
            control if control <= '\u{1f}' => {
                escaped.push_str(&format!("\\u{:04x}", control as u32));
            }
            other => escaped.push(other),
        }
    }
    escaped.push('"');
    escaped
}

fn base64(bytes: &[u8]) -> String {
    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut encoded = String::with_capacity(bytes.len().div_ceil(3) * 4);
    for chunk in bytes.chunks(3) {
        let first = chunk[0];
        let second = chunk.get(1).copied().unwrap_or(0);
        let third = chunk.get(2).copied().unwrap_or(0);
        encoded.push(ALPHABET[(first >> 2) as usize] as char);
        encoded.push(ALPHABET[(((first & 0x03) << 4) | (second >> 4)) as usize] as char);
        if chunk.len() > 1 {
            encoded.push(ALPHABET[(((second & 0x0f) << 2) | (third >> 6)) as usize] as char);
        } else {
            encoded.push('=');
        }
        if chunk.len() > 2 {
            encoded.push(ALPHABET[(third & 0x3f) as usize] as char);
        } else {
            encoded.push('=');
        }
    }
    encoded
}

fn csp_hash(content: &str) -> String {
    base64(&Sha256::digest(content.as_bytes()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn base64_vectors() {
        assert_eq!(base64(b""), "");
        assert_eq!(base64(b"f"), "Zg==");
        assert_eq!(base64(b"fo"), "Zm8=");
        assert_eq!(base64(b"foo"), "Zm9v");
        assert_eq!(base64(b"foobar"), "Zm9vYmFy");
    }

    #[test]
    fn script_sensitive_characters_are_escaped() {
        assert_eq!(
            javascript_string("</script>\n\"&"),
            "\"\\u003c/script\\u003e\\n\\\"\\u0026\""
        );
    }

    #[test]
    fn content_security_hash_vector() {
        assert_eq!(
            csp_hash("hello"),
            "LPJNul+wow4m6DsqxbninhsWHlwfp0JecwQzYpOLmCQ="
        );
    }
}
