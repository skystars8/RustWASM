import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { Worker } from "node:worker_threads";

const arguments_ = process.argv.slice(2);
const embedded = arguments_.includes("--embedded");
const wasmPath = resolve(
  arguments_.find((argument) => argument !== "--embedded") ??
    "target/wasm32-unknown-unknown/release/localvault.wasm",
);
const worker = new Worker(new URL("./node-worker-wrapper.mjs", import.meta.url), {
  type: "module",
});
const pending = new Map();
let nextId = 1;
let readyResolve;
const ready = new Promise((resolveReady) => {
  readyResolve = resolveReady;
});

worker.on("message", (message) => {
  if (message?.harnessReady) {
    readyResolve();
    return;
  }
  const request = pending.get(message?.id);
  if (!request) return;
  pending.delete(message.id);
  if (message.ok) request.resolve(message.value);
  else {
    const error = new Error(message.error?.message ?? "Worker operation failed.");
    error.code = message.error?.code ?? 0;
    request.reject(error);
  }
});
worker.on("error", (error) => {
  for (const request of pending.values()) request.reject(error);
  pending.clear();
});

function call(operation, data = {}, transfer = []) {
  const id = nextId++;
  return new Promise((resolveCall, rejectCall) => {
    pending.set(id, { resolve: resolveCall, reject: rejectCall });
    worker.postMessage({ id, operation, data }, transfer);
  });
}

await ready;
if (embedded) {
  const bytes = await readFile(wasmPath);
  const wasmBytes = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  await call("init", { wasmBytes }, [wasmBytes]);
  assert.equal(wasmBytes.byteLength, 0, "embedded WASM transfer was not detached");
} else {
  await call("init", { wasmUrl: pathToFileURL(wasmPath).href });
}

await assert.rejects(call("notAnOperation"), /different versions/u);

const encoder = new TextEncoder();
const password = encoder.encode("correct horse battery staple");
const passwordTransfer = password.slice().buffer;
const plaintext = new Uint8Array(128 * 1024 + 19);
for (let index = 0; index < plaintext.length; index += 1) plaintext[index] = index % 239;
const salt = new Uint8Array(16).fill(0x31);
const noncePrefix = new Uint8Array(16).fill(0x72);

const started = await call(
  "encryptStart",
  {
    password: passwordTransfer,
    filename: "worker-round-trip.bin",
    mimeType: "application/octet-stream",
    size: BigInt(plaintext.length),
    modified: 1_787_398_400_000n,
    salt: salt.buffer,
    noncePrefix: noncePrefix.buffer,
  },
  [passwordTransfer, salt.buffer, noncePrefix.buffer],
);
assert.equal(passwordTransfer.byteLength, 0, "transferred password copy was not detached");
assert.equal(password.byteLength, 28, "caller-owned password bytes were unexpectedly detached");
password.fill(0);

const plaintextTransfer = plaintext.slice().buffer;
const ciphertext = await call(
  "encryptChunk",
  { handle: started.handle, index: 0n, bytes: plaintextTransfer },
  [plaintextTransfer],
);
assert.equal(plaintextTransfer.byteLength, 0, "transferred plaintext was not detached");
await call("finish", { handle: started.handle });

const inspectionPrefix = started.header.slice(0, 80);
const inspection = await call("inspect", { bytes: inspectionPrefix }, [inspectionPrefix]);
assert.equal(
  inspection.expectedContainerSize,
  BigInt(started.header.byteLength + ciphertext.byteLength),
  "worker inspection calculated the wrong container size",
);

const decryptPassword = encoder.encode("correct horse battery staple");
const decryptPasswordTransfer = decryptPassword.slice().buffer;
const decryptHeader = started.header.slice(0);
const decryptStarted = await call(
  "decryptStart",
  { password: decryptPasswordTransfer, header: decryptHeader },
  [decryptPasswordTransfer, decryptHeader],
);
decryptPassword.fill(0);
assert.equal(decryptStarted.filename, "worker-round-trip.bin");
assert.equal(decryptStarted.mimeType, "application/octet-stream");

const ciphertextTransfer = ciphertext.slice(0);
const recoveredBuffer = await call(
  "decryptChunk",
  { handle: decryptStarted.handle, index: 0n, bytes: ciphertextTransfer },
  [ciphertextTransfer],
);
await call("finish", { handle: decryptStarted.handle });
assert.deepEqual(new Uint8Array(recoveredBuffer), plaintext, "worker round trip changed bytes");

const wrongPassword = encoder.encode("this password is definitely wrong").buffer;
const wrongHeader = started.header.slice(0);
await assert.rejects(
  call(
    "decryptStart",
    { password: wrongPassword, header: wrongHeader },
    [wrongPassword, wrongHeader],
  ),
  (error) => error.code === 1,
);

await worker.terminate();
console.log(
  JSON.stringify({
    worker: embedded ? "embedded-ok" : "url-ok",
    plaintextBytes: plaintext.length,
    ciphertextBytes: ciphertext.byteLength,
    transferDetachment: "verified",
    wrongPassword: "rejected",
  }),
);
