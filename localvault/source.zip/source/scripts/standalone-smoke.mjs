import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

const [html, css, app, worker, wasm] = await Promise.all([
  readFile(process.argv[2] ?? "localvault.html", "utf8"),
  readFile("web/styles.css", "utf8"),
  readFile("web/app.js", "utf8"),
  readFile("web/worker.js", "utf8"),
  readFile("target/wasm32-unknown-unknown/release/localvault.wasm"),
]);

assert.match(html, /^<!doctype html>/u);
assert.ok(
  html.includes("worker-src blob:") &&
    html.includes("'wasm-unsafe-eval'") &&
    html.includes("'sha256-"),
  "standalone CSP does not permit its embedded worker and WASM",
);
assert.ok(!html.includes("'unsafe-inline'"), "standalone CSP permits arbitrary inline content");
assert.ok(!html.includes('<link rel="stylesheet" href="styles.css">'));
assert.ok(!html.includes('<script type="module" src="app.js"></script>'));
assert.ok(html.includes(`<style>\n${css}\n</style>`), "CSS was not embedded exactly");
assert.ok(html.includes(`\n${app}\n</script>`), "application code was not embedded exactly");

const csp = html.match(/http-equiv="Content-Security-Policy"\s+content="([^"]+)"/u)?.[1];
const styleContent = html.match(/<style>([\s\S]*?)<\/style>/u)?.[1];
const scriptContent = html.match(/<script>([\s\S]*?)<\/script>/u)?.[1];
assert.ok(csp && styleContent && scriptContent, "standalone CSP or inline content was not found");
const cspHash = (content) => createHash("sha256").update(content).digest("base64");
assert.ok(csp.includes(`'sha256-${cspHash(styleContent)}'`), "standalone CSS hash is stale");
assert.ok(csp.includes(`'sha256-${cspHash(scriptContent)}'`), "standalone script hash is stale");

const configuration = html.match(
  /Object\.freeze\(\{ workerSource: (.+), wasmBase64: ("[A-Za-z0-9+/=]+") \}\);/u,
);
assert.ok(configuration, "embedded asset configuration was not found");
const embeddedWorker = JSON.parse(configuration[1]);
const embeddedWasm = Buffer.from(JSON.parse(configuration[2]), "base64");
assert.equal(embeddedWorker, worker, "embedded worker differs from its source");
assert.deepEqual(embeddedWasm, wasm, "embedded WASM differs from its release binary");

assert.equal((html.match(/<script>/gu) ?? []).length, 1, "expected one inline script");
assert.equal((html.match(/<\/script>/gu) ?? []).length, 1, "worker text escaped the script tag");

console.log(
  JSON.stringify({
    standalone: "ok",
    htmlBytes: Buffer.byteLength(html),
    wasmBytes: embeddedWasm.byteLength,
    workerBytes: Buffer.byteLength(embeddedWorker),
    companionRequests: 0,
  }),
);
