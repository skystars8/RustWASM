import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

const wasmPath =
  process.argv[2] ?? "target/wasm32-unknown-unknown/release/localvault.wasm";
const wasmBytes = await readFile(wasmPath);
const { instance } = await WebAssembly.instantiate(wasmBytes, {});
const wasm = instance.exports;
const encoder = new TextEncoder();

assert.equal(wasm.localvault_abi_version(), 1, "unexpected WASM ABI version");

function allocate(value) {
  const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
  if (bytes.length === 0) return { pointer: 0, length: 0 };
  const pointer = wasm.localvault_alloc(bytes.length);
  assert.notEqual(pointer, 0, "WASM allocation failed");
  new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes);
  return { pointer, length: bytes.length };
}

function release(region) {
  if (region.pointer) wasm.localvault_dealloc(region.pointer, region.length);
}

function result(pointer) {
  assert.notEqual(pointer, 0, "WASM returned a null result");
  const prefix = new DataView(wasm.memory.buffer, pointer, 8);
  const status = prefix.getUint32(0, true);
  const length = prefix.getUint32(4, true);
  const payload = new Uint8Array(wasm.memory.buffer, pointer + 8, length).slice();
  wasm.localvault_result_free(pointer);
  return { status, payload };
}

function halves(value) {
  const number = BigInt(value);
  return [Number(number & 0xffff_ffffn), Number((number >> 32n) & 0xffff_ffffn)];
}

function expectSuccess(response, operation) {
  if (response.status !== 0) {
    throw new Error(`${operation}: ${new TextDecoder().decode(response.payload)}`);
  }
  return response.payload;
}

const password = allocate(encoder.encode("correct horse battery staple"));
const filename = allocate(encoder.encode("round-trip.bin"));
const mime = allocate(encoder.encode("application/octet-stream"));
const salt = allocate(new Uint8Array(16).fill(0x11));
const nonce = allocate(new Uint8Array(16).fill(0x22));
const plaintext = new Uint8Array(4 * 1024 * 1024 + 37);
for (let index = 0; index < plaintext.length; index += 1) plaintext[index] = index % 251;

const [sizeLow, sizeHigh] = halves(plaintext.length);
const [modifiedLow, modifiedHigh] = halves(1_787_398_400_000n);
const start = expectSuccess(
  result(
    wasm.localvault_encrypt_start(
      password.pointer,
      password.length,
      filename.pointer,
      filename.length,
      mime.pointer,
      mime.length,
      sizeLow,
      sizeHigh,
      modifiedLow,
      modifiedHigh,
      salt.pointer,
      salt.length,
      nonce.pointer,
      nonce.length,
    ),
  ),
  "encrypt start",
);
const encryptHandle = new DataView(start.buffer, start.byteOffset, 4).getUint32(0, true);
const header = start.slice(4);
const headerSha256 = createHash("sha256").update(header).digest("hex");
assert.equal(
  headerSha256,
  "3affb4130c6820e0f5329bdeb04261f6639d770fab8261c4461348d7cec422f0",
  "the deterministic v1 header fixture changed",
);
const encryptedChunks = [];

for (let index = 0; index < 2; index += 1) {
  const begin = index * 4 * 1024 * 1024;
  const end = Math.min(plaintext.length, begin + 4 * 1024 * 1024);
  const input = allocate(plaintext.slice(begin, end));
  const [indexLow, indexHigh] = halves(index);
  encryptedChunks.push(
    expectSuccess(
      result(
        wasm.localvault_encrypt_chunk(
          encryptHandle,
          indexLow,
          indexHigh,
          input.pointer,
          input.length,
        ),
      ),
      `encrypt chunk ${index}`,
    ),
  );
  release(input);
}
expectSuccess(result(wasm.localvault_finish(encryptHandle)), "encrypt finish");

const headerRegion = allocate(header);
const inspection = expectSuccess(
  result(wasm.localvault_inspect(headerRegion.pointer, headerRegion.length)),
  "inspect header",
);
const inspectionView = new DataView(
  inspection.buffer,
  inspection.byteOffset,
  inspection.byteLength,
);
const expectedContainerSize = inspectionView.getBigUint64(36, true);
const actualContainerSize = BigInt(
  header.length + encryptedChunks.reduce((sum, chunk) => sum + chunk.length, 0),
);
assert.equal(expectedContainerSize, actualContainerSize, "container size mismatch");

const decryptStart = expectSuccess(
  result(
    wasm.localvault_decrypt_start(
      password.pointer,
      password.length,
      headerRegion.pointer,
      headerRegion.length,
    ),
  ),
  "decrypt start",
);
const decryptView = new DataView(
  decryptStart.buffer,
  decryptStart.byteOffset,
  decryptStart.byteLength,
);
const decryptHandle = decryptView.getUint32(0, true);
const recovered = new Uint8Array(plaintext.length);
let recoveredOffset = 0;

for (let index = 0; index < encryptedChunks.length; index += 1) {
  const input = allocate(encryptedChunks[index]);
  const [indexLow, indexHigh] = halves(index);
  const decrypted = expectSuccess(
    result(
      wasm.localvault_decrypt_chunk(
        decryptHandle,
        indexLow,
        indexHigh,
        input.pointer,
        input.length,
      ),
    ),
    `decrypt chunk ${index}`,
  );
  recovered.set(decrypted, recoveredOffset);
  recoveredOffset += decrypted.length;
  release(input);
}
expectSuccess(result(wasm.localvault_finish(decryptHandle)), "decrypt finish");
assert.deepEqual(recovered, plaintext, "decrypted bytes differ from the original");

const wrongPassword = allocate(encoder.encode("this password is definitely wrong"));
const rejected = result(
  wasm.localvault_decrypt_start(
    wrongPassword.pointer,
    wrongPassword.length,
    headerRegion.pointer,
    headerRegion.length,
  ),
);
assert.equal(rejected.status, 1, "wrong password did not return authentication failure");

for (const region of [password, filename, mime, salt, nonce, headerRegion, wrongPassword]) {
  release(region);
}

console.log(
  JSON.stringify({
    abi: wasm.localvault_abi_version(),
    chunks: encryptedChunks.length,
    plaintextBytes: plaintext.length,
    containerBytes: Number(actualContainerSize),
    wrongPasswordStatus: rejected.status,
    headerSha256,
    wasmBytes: wasmBytes.length,
  }),
);
