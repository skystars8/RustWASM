import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { parentPort } from "node:worker_threads";

if (!parentPort) throw new Error("This harness must run inside a Node worker thread.");

const networkFetch = globalThis.fetch;
globalThis.fetch = async (input, options) => {
  const url = new URL(typeof input === "string" ? input : input.url);
  if (url.protocol !== "file:") return networkFetch(input, options);
  const bytes = await readFile(fileURLToPath(url));
  return new Response(bytes, {
    status: 200,
    headers: { "content-type": "application/wasm" },
  });
};

globalThis.self = {
  addEventListener(type, listener) {
    if (type === "message") parentPort.on("message", (data) => listener({ data }));
  },
  postMessage(value, transfer = []) {
    parentPort.postMessage(value, transfer);
  },
};

await import("../web/worker.js");
parentPort.postMessage({ harnessReady: true });
