//! Minimal C-style ABI consumed by the in-page Web Worker.
//!
//! All cryptographic state stays inside this module's registry. JavaScript
//! receives opaque, single-use handles and owned result buffers. Pointer/length
//! pairs are checked against allocation registries before they are dereferenced.

use std::{cell::RefCell, collections::BTreeMap, slice, str};

use zeroize::{Zeroize, Zeroizing};

use super::{inspect_header, Decryptor, Encryptor, FileMetadata, VaultError, FIXED_HEADER_LEN};

enum Session {
    Encrypt(Encryptor),
    Decrypt(Decryptor),
}

thread_local! {
    static SESSIONS: RefCell<Vec<Option<Session>>> = const { RefCell::new(Vec::new()) };
    static INPUT_ALLOCATIONS: RefCell<BTreeMap<u32, usize>> = const { RefCell::new(BTreeMap::new()) };
    static RESULT_ALLOCATIONS: RefCell<BTreeMap<u32, usize>> = const { RefCell::new(BTreeMap::new()) };
}

#[no_mangle]
pub extern "C" fn localvault_abi_version() -> u32 {
    1
}

/// Allocates an initialized input region which must be returned with
/// `localvault_dealloc`.
#[no_mangle]
pub extern "C" fn localvault_alloc(len: u32) -> u32 {
    if len == 0 {
        return 0;
    }
    let Ok(length) = usize::try_from(len) else {
        return 0;
    };
    let bytes = vec![0_u8; length].into_boxed_slice();
    let pointer = Box::into_raw(bytes) as *mut u8 as u32;
    INPUT_ALLOCATIONS.with_borrow_mut(|allocations| {
        allocations.insert(pointer, length);
    });
    pointer
}

/// Frees and clears a region previously returned by `localvault_alloc`.
/// Unknown, repeated, or mismatched regions are ignored.
#[no_mangle]
pub extern "C" fn localvault_dealloc(pointer: u32, len: u32) {
    if pointer == 0 || len == 0 {
        return;
    }
    let Ok(length) = usize::try_from(len) else {
        return;
    };
    let registered = INPUT_ALLOCATIONS
        .with_borrow(|allocations| allocations.get(&pointer).copied() == Some(length));
    if !registered {
        return;
    }
    INPUT_ALLOCATIONS.with_borrow_mut(|allocations| {
        allocations.remove(&pointer);
    });
    let raw = std::ptr::slice_from_raw_parts_mut(pointer as *mut u8, length);
    // SAFETY: The allocation registry only contains exact boxed-slice pointers
    // and lengths created above. Removing the entry prevents a second free.
    let mut bytes = unsafe { Box::from_raw(raw) };
    bytes.zeroize();
}

/// Frees and clears an owned success/error result returned by an operation.
/// Unknown or repeated pointers are ignored.
#[no_mangle]
pub extern "C" fn localvault_result_free(pointer: u32) {
    if pointer == 0 {
        return;
    }
    let Some(total_len) =
        RESULT_ALLOCATIONS.with_borrow_mut(|allocations| allocations.remove(&pointer))
    else {
        return;
    };
    let raw = std::ptr::slice_from_raw_parts_mut(pointer as *mut u8, total_len);
    // SAFETY: The result registry contains the exact pointer and boxed-slice
    // length created by `owned_result`, and the entry was removed above.
    let mut bytes = unsafe { Box::from_raw(raw) };
    bytes.zeroize();
}

#[allow(clippy::too_many_arguments)]
#[no_mangle]
pub extern "C" fn localvault_encrypt_start(
    password_ptr: u32,
    password_len: u32,
    filename_ptr: u32,
    filename_len: u32,
    mime_ptr: u32,
    mime_len: u32,
    size_low: u32,
    size_high: u32,
    modified_low: u32,
    modified_high: u32,
    salt_ptr: u32,
    salt_len: u32,
    nonce_ptr: u32,
    nonce_len: u32,
) -> u32 {
    operation(|| {
        let password = Zeroizing::new(copy_input(password_ptr, password_len)?);
        let filename_bytes = copy_input(filename_ptr, filename_len)?;
        let mime_bytes = copy_input(mime_ptr, mime_len)?;
        let salt = copy_input(salt_ptr, salt_len)?;
        let nonce = copy_input(nonce_ptr, nonce_len)?;
        let filename = str::from_utf8(&filename_bytes).map_err(|_| VaultError::InvalidMetadata)?;
        let mime_type = str::from_utf8(&mime_bytes).map_err(|_| VaultError::InvalidMetadata)?;
        let metadata = FileMetadata {
            filename: filename.to_owned(),
            mime_type: mime_type.to_owned(),
            modified_ms: join_u64(modified_low, modified_high),
        };
        let encryptor = Encryptor::new(
            &password,
            &metadata,
            join_u64(size_low, size_high),
            &salt,
            &nonce,
        )?;
        let header = encryptor.header().to_vec();
        let handle = insert_session(Session::Encrypt(encryptor))?;
        let mut payload = Vec::with_capacity(4 + header.len());
        payload.extend_from_slice(&handle.to_le_bytes());
        payload.extend_from_slice(&header);
        Ok(payload)
    })
}

#[no_mangle]
pub extern "C" fn localvault_encrypt_chunk(
    handle: u32,
    index_low: u32,
    index_high: u32,
    input_ptr: u32,
    input_len: u32,
) -> u32 {
    operation(|| {
        with_input(input_ptr, input_len, |plaintext| {
            with_session(handle, |session| match session {
                Session::Encrypt(encryptor) => {
                    encryptor.encrypt_chunk(join_u64(index_low, index_high), plaintext)
                }
                Session::Decrypt(_) => Err(VaultError::InvalidState),
            })
        })
    })
}

#[no_mangle]
pub extern "C" fn localvault_inspect(input_ptr: u32, input_len: u32) -> u32 {
    operation(|| {
        let bytes = copy_input(input_ptr, input_len)?;
        let public = inspect_header(&bytes)?;
        let mut payload = Vec::with_capacity(44);
        payload.extend_from_slice(&public.header_len.to_le_bytes());
        payload.extend_from_slice(&public.memory_kib.to_le_bytes());
        payload.extend_from_slice(&public.iterations.to_le_bytes());
        payload.extend_from_slice(&public.lanes.to_le_bytes());
        payload.extend_from_slice(&public.chunk_size.to_le_bytes());
        payload.extend_from_slice(&public.plaintext_size.to_le_bytes());
        payload.extend_from_slice(&public.chunk_count.to_le_bytes());
        payload.extend_from_slice(&public.expected_container_size.to_le_bytes());
        Ok(payload)
    })
}

#[no_mangle]
pub extern "C" fn localvault_decrypt_start(
    password_ptr: u32,
    password_len: u32,
    header_ptr: u32,
    header_len: u32,
) -> u32 {
    operation(|| {
        let password = Zeroizing::new(copy_input(password_ptr, password_len)?);
        let header = copy_input(header_ptr, header_len)?;
        let decryptor = Decryptor::new(&password, &header)?;
        let public = decryptor.public_header().clone();
        let metadata = decryptor.metadata().clone();
        let handle = insert_session(Session::Decrypt(decryptor))?;
        let filename = metadata.filename.as_bytes();
        let mime = metadata.mime_type.as_bytes();
        let mut payload = Vec::with_capacity(40 + filename.len() + mime.len());
        payload.extend_from_slice(&handle.to_le_bytes());
        payload.extend_from_slice(&public.header_len.to_le_bytes());
        payload.extend_from_slice(&public.chunk_size.to_le_bytes());
        payload.extend_from_slice(&public.plaintext_size.to_le_bytes());
        payload.extend_from_slice(&public.chunk_count.to_le_bytes());
        payload.extend_from_slice(&metadata.modified_ms.to_le_bytes());
        payload.extend_from_slice(&(filename.len() as u16).to_le_bytes());
        payload.extend_from_slice(&(mime.len() as u16).to_le_bytes());
        payload.extend_from_slice(filename);
        payload.extend_from_slice(mime);
        Ok(payload)
    })
}

#[no_mangle]
pub extern "C" fn localvault_decrypt_chunk(
    handle: u32,
    index_low: u32,
    index_high: u32,
    input_ptr: u32,
    input_len: u32,
) -> u32 {
    operation(|| {
        with_input(input_ptr, input_len, |ciphertext| {
            with_session(handle, |session| match session {
                Session::Decrypt(decryptor) => {
                    decryptor.decrypt_chunk(join_u64(index_low, index_high), ciphertext)
                }
                Session::Encrypt(_) => Err(VaultError::InvalidState),
            })
        })
    })
}

#[no_mangle]
pub extern "C" fn localvault_finish(handle: u32) -> u32 {
    operation(|| {
        let session = take_session(handle)?;
        match session {
            Session::Encrypt(encryptor) => encryptor.finish()?,
            Session::Decrypt(decryptor) => decryptor.finish()?,
        }
        Ok(Vec::new())
    })
}

#[no_mangle]
pub extern "C" fn localvault_abort(handle: u32) {
    let _ = take_session(handle);
}

fn operation(action: impl FnOnce() -> Result<Vec<u8>, VaultError>) -> u32 {
    match action() {
        Ok(mut payload) => {
            let result = owned_result(0, &payload);
            payload.zeroize();
            result
        }
        Err(error) => owned_result(error.code(), error.to_string().as_bytes()),
    }
}

fn owned_result(status: u32, payload: &[u8]) -> u32 {
    let Ok(payload_len) = u32::try_from(payload.len()) else {
        return owned_result(
            VaultError::FileTooLarge.code(),
            VaultError::FileTooLarge.to_string().as_bytes(),
        );
    };
    let mut bytes = Vec::with_capacity(8 + payload.len());
    bytes.extend_from_slice(&status.to_le_bytes());
    bytes.extend_from_slice(&payload_len.to_le_bytes());
    bytes.extend_from_slice(payload);
    let boxed = bytes.into_boxed_slice();
    let total_len = boxed.len();
    let pointer = Box::into_raw(boxed) as *mut u8 as u32;
    RESULT_ALLOCATIONS.with_borrow_mut(|allocations| {
        allocations.insert(pointer, total_len);
    });
    pointer
}

fn insert_session(session: Session) -> Result<u32, VaultError> {
    SESSIONS.with_borrow_mut(|sessions| {
        if let Some(index) = sessions.iter().position(Option::is_none) {
            sessions[index] = Some(session);
            return u32::try_from(index + 1).map_err(|_| VaultError::InvalidState);
        }
        sessions.push(Some(session));
        u32::try_from(sessions.len()).map_err(|_| VaultError::InvalidState)
    })
}

fn with_session<T>(
    handle: u32,
    action: impl FnOnce(&mut Session) -> Result<T, VaultError>,
) -> Result<T, VaultError> {
    let index = handle.checked_sub(1).ok_or(VaultError::InvalidState)? as usize;
    SESSIONS.with_borrow_mut(|sessions| {
        let session = sessions
            .get_mut(index)
            .and_then(Option::as_mut)
            .ok_or(VaultError::InvalidState)?;
        action(session)
    })
}

fn take_session(handle: u32) -> Result<Session, VaultError> {
    let index = handle.checked_sub(1).ok_or(VaultError::InvalidState)? as usize;
    SESSIONS.with_borrow_mut(|sessions| {
        sessions
            .get_mut(index)
            .and_then(Option::take)
            .ok_or(VaultError::InvalidState)
    })
}

fn join_u64(low: u32, high: u32) -> u64 {
    u64::from(low) | (u64::from(high) << 32)
}

fn copy_input(pointer: u32, len: u32) -> Result<Vec<u8>, VaultError> {
    with_input(pointer, len, |bytes| Ok(bytes.to_vec()))
}

fn with_input<T>(
    pointer: u32,
    len: u32,
    action: impl for<'a> FnOnce(&'a [u8]) -> Result<T, VaultError>,
) -> Result<T, VaultError> {
    if len == 0 {
        return action(&[]);
    }
    if pointer == 0 {
        return Err(VaultError::InvalidState);
    }
    let len = usize::try_from(len).map_err(|_| VaultError::FileTooLarge)?;
    let registered = INPUT_ALLOCATIONS
        .with_borrow(|allocations| allocations.get(&pointer).copied() == Some(len));
    if !registered {
        return Err(VaultError::InvalidState);
    }
    // SAFETY: The input registry contains the exact live boxed-slice pointer and
    // length. WebAssembly calls are synchronous, so JavaScript cannot free the
    // allocation before this higher-ranked callback returns.
    let bytes = unsafe { slice::from_raw_parts(pointer as *const u8, len) };
    action(bytes)
}

const _: () = assert!(FIXED_HEADER_LEN == 80);
